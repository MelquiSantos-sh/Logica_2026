# string-C
atividades
