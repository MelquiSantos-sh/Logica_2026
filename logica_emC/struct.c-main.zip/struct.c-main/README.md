# struct.c
atividade 
