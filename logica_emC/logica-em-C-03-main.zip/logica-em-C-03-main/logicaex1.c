#include <stdio.h>
#include <math.h>

int main() {

   double numero, raiz;

    printf("Digite um numero: ");
    scanf("%lf", &numero);

    raiz = sqrt(numero);

    printf("O resultado e : %.0f", raiz);

    return 0;
}
