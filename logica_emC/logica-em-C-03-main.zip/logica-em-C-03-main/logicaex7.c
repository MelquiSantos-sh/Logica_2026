#include <stdio.h>

int main() {

    // declaracao de variaveis
    int numero;
    int milhar, centena, dezena, unidade, soma;

    // entrada
    printf("Digite um numero de quatro digitos: ");
    scanf("%d", &numero);

    // processamento
    // separando os digitos

    milhar = numero / 1000;
    centena = (numero % 1000) / 100;
    dezena = (numero % 100) / 10;
    unidade = numero % 10;

    // soma dos digitos
    soma = milhar + centena + dezena + unidade;

    // saida
    printf("Soma dos digitos = %d\n", soma);

    return 0;
}

