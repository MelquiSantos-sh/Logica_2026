#include <stdio.h>
#include <math.h>
int main() {    
    //declaracao de variaveis 
    float a, b, c, d;
    float mh, mq;
    //entradas
    printf("Digite o valor de a: ");
    scanf("%f", &a, &b, &c, &d);
   
    //processamento 
// Media Harmonica
// Formula matematica:
// MH = 4 / (1/a + 1/b + 1/c + 1/d)
//
// 1) inverter cada valor (1/a, 1/b, 1/c, 1/d)
// 2) somar todos
// 3) dividir 4 pelo resultado
    mh = 4 / (1/a + 1/b + 1/c + 1/d);
// Media Quadratica
// Formula matematica:
// MQ = √((a² + b² + c² + d²) / 4)
//
// 1) elevar cada valor ao quadrado (a*a, b*b, c*c, d*d)
// 2) somar todos os quadrados
// 3) dividir o resultado por 4
// 4) calcular a raiz quadrada usando sqrt()

    mq = sqrt((a*a + b*b + c*c + d*d) / 4);
    //saidas
    printf("Media harmonica: %.2f\n", mh);
    printf("Media quadratica: %.2f\n", mq);
//fim
    return 0;
    
}

