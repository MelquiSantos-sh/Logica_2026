# logica em C 03
atividade logica ifpr2026
