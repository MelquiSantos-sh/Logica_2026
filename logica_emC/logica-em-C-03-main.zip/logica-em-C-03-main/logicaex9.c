#include <stdio.h>

int main() {

    // declaracao de variaveis
    int v1, v2, aux;

    // entrada
    printf("Digite o valor de v1: ");
    scanf("%d", &v1);

    printf("Digite o valor de v2: ");
    scanf("%d", &v2);

    // mostrar valores iniciais
    printf("Valores iniciais:\n");
    printf("v1 = %d\n", v1);
    printf("v2 = %d\n", v2);

    // processamento - troca dos valores
    aux = v1;
    v1 = v2;
    v2 = aux;

    // mostrar valores trocados
    printf("Valores apos a troca:\n");
    printf("v1 = %d\n", v1);
    printf("v2 = %d\n", v2);

    return 0;
}
