#include <stdio.h>

int main() {

    // declaracao de variaveis
    int segundos, horas, minutos, seg, resto;

    // entrada
    printf("Digite o tempo em segundos: ");
    scanf("%d", &segundos);

    // processamento

    // calcula as horas
    horas = segundos / 3600;

    // calcula o resto dos segundos
    resto = segundos % 3600;

    // calcula os minutos
    minutos = resto / 60;

    // calcula os segundos finais
    seg = resto % 60;

    // saida
    printf("%ds = %d:%d:%d\n", segundos, horas, minutos, seg);

    return 0;
}