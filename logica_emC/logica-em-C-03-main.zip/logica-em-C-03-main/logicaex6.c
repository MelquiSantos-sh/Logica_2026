#include <stdio.h> 
int main() {    
    //declaracao de variaveis 
    float produto,parcelas;
    //entradas
    printf("Digite o valor do produto: ");
    scanf("%f", &produto);

    //processamento

parcelas= produto / 5;
   // Saida
    printf("Compra parcelada\n");
    printf("5 x %.2f = %.2f\n", parcelas, produto);
        //fim
    return 0;
}
