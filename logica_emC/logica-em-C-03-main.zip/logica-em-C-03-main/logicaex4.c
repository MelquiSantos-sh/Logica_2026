#include <stdio.h>
#include <math.h>
            //inicio
int main() 
            //declaraçao de variaveis 
{  
	int nota1, nota2, nota3, media;
	       //entradas
 printf("Digite suas notas em seguida e aperte enter em seguida: ");
    scanf("%d",&nota1);
    scanf("%d",&nota2);
    scanf("%d",&nota3);
    
          //processamento
          
  media= (float)(nota1+nota2+nota3)/3;
         //saida
  printf("sua media de nota e %.1d",media);
         //fim
    return 0;
    
  }  
  
  
  
  
          
