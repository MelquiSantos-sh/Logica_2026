#include <stdio.h>
#include <math.h>
            //inicio
int main() 
            //declaraçao de variaveis 
 {
	 double numero, quadrado,cubo;
	 
	         //entradas
	 printf("Qual o numero do quadrado?");
         scanf("%lf",&numero);
         
     quadrado=pow(numero,2);
     cubo= pow(numero,3);
     
     printf("numero\tquadrado\tcubo\n");
     printf("%.2f\t%.2f\t	%.2f",numero,quadrado,cubo);
     
     return 0;
     
 }
     
