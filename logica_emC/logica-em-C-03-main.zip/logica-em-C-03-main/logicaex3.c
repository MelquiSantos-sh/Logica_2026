#include <stdio.h>
#include <math.h>
            //inicio
int main() 
            //declaraçao de variaveis 
{
	double numero,arcima,arbaixo;
	        //entradas
    printf("registre seu numero real para o calculo:");
      scanf("%lf",&numero);
                //processamento
    arbaixo=floor(numero);
    arcima=ceil(numero);
               //saida
    
    printf("seu floor e %.0f\n",arbaixo); 
    printf("seu ceil e %.0f\n",arcima);
           //fim
    return 0;
    
 }                          
