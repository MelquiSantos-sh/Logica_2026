#include <stdio.h>

  int main()
 {                 //inicio
	      // declaraçao das variaveis 
	 int numero_inteiro,sucessor, antecessor;
	              // entrada
	 printf("Digite seu numero inteiro:\n");
	   scanf("%d",&numero_inteiro);
	             //processamento
	 sucessor= numero_inteiro + 1;
	 antecessor= numero_inteiro - 1;
	              //saida

	 printf("seu numero e %d \n",numero_inteiro);  
	 printf("Seu sucessor e %d \n",sucessor);
	 printf("Seu antecessor e %d \n",antecessor);    
	 
	 return 0;
	              // fim   
	   
	}  
	
