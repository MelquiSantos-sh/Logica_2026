#include <stdio.h>
 
 int main ()
                   //inicio
               // variaveis         
{
	int numero_inteiro, dobro; 
           //entradas
  printf("Digite um numero inteiro: \n");
    scanf("%d",&numero_inteiro);
         // processamento
         
   dobro= numero_inteiro * 2;
         //saida
         
   printf("O dobro do seu numero inteiro e %d",dobro);
   
   return 0;
    
 }
   
    
