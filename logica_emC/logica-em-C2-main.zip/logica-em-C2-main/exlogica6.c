#include <stdio.h>
               // inicio 
   int main()
   
 {               // declaracao de bariaveis
	 
	 float celcius,fahren,kevin; 
	 
				//entradas
	printf("medida de escala de temperatura\n");
	
	printf("Digite a temperatura em celcius: ");		
       scanf("%f",&celcius);

              // processamento
     // Conversão para Kelvin        
     kevin=celcius+273;   
     // Conversão para Fahrenheit usando Kelvin     
     fahren=1.8 * (kevin-273)+32;
     
              //saidas
     // Exibe o resultado com 1 casa decimal
     printf("%.1fC = %.1fF = %.1fK\n", celcius,fahren,kevin);
     
                //fim 
     return 0;
     
 }    
