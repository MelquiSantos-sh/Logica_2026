#include <stdio.h>

int main ()
                     // inicio
{         //dclaraçao de variaveis 
	
	int base,altura,result;
	                 //entradas
	                 
	printf("Digite o valor da base: \n");                
	       scanf("%d",&base);
	printf("Digite o valor da altura: \n");       
	       scanf("%d",&altura);

	              //processamento
	   
	result= base * altura;
	
	                 // saida
	
	printf("O resultado da area do retangulo e de %d",result);
	                //fim
	return 0;
	
}     
