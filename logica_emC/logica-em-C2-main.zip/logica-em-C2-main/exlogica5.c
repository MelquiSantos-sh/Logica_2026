#include <stdio.h>
int main()
{     
  float valorPago, produto,troco;
  
    printf("Qual o valor o cliente passou?");
    
      scanf("%f",&valorPago);
      
    printf("Qual o valor do produto?");   
      
        scanf("%f",&produto);
        
        
    troco= valorPago - produto;
    
    
     printf("Seu produto custa %.2f \n", produto);
     printf("Seu cliente lhe pagou R$ %.2f \n",valorPago);
     printf("seu troco e de %.2f \n",troco);
   
   return 0;


}
