#include <stdio.h>

int main ()
                     // inicio
{         //dclaraçao de variaveis 
	
	int real1,real2,real3,real4,media;
	                 //entradas
	                 
	printf("Digite 4 numeros inteiros em seguida e aperte enter apos digitar o numero \n");                
	       scanf("%d",&real1);
	       scanf("%d",&real2);
	       scanf("%d",&real3);
	       scanf("%d",&real4);
	              //processamento
	   
	media=(real1 + real2 + real3 + real4) / 4;
	
	                 // saida
	
	printf("O resultado da media dos 4 numeros inteiros e %d",media);
	                //fim
	return 0;
	
}     
	
	   
