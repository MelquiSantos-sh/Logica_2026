# logica em C2
segunda atividade enviada 
