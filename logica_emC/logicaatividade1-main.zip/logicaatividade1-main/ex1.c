#include <stdio.h>

	int main()
	{     // declaracao de variaveis 
		int variavelA,variavelB,adicao,subtracao,multiplicacao;
		float divisao;
		   // entrada
		printf("Qual valor de A?");
			scanf ("%d",&variavelA);
		printf("Qual valor de B?");
			scanf ("%d", &variavelB);
			// processamento
		adicao= variavelA + variavelB;
		multiplicacao= variavelA * variavelB;
		subtracao= variavelA - variavelB;
		divisao= variavelA / variavelB;
	            // saida
	     
	     
	  printf("Esse seria o valor da adiçao %d \n",adicao);
	  printf("Esse seria o valor da divisao %.1f \n", divisao);
	  printf("Esse seria o valor da mutiplicaçao %d \n",multiplicacao);
	  printf("Esse seria o valor da subtraçao %d \n",subtracao);
	  
	  
	  return 0;
	  //fim
  }
