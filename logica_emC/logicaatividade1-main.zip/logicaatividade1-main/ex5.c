
#include <stdio.h>

int main()
    //inicio
{
	   //declaraçao das variaveis 
	float largura,comprimento,valor_metro,custo,total_M;
	 // entradas
	 printf("Qual a largura do quarto? \n");
	    scanf("%f",&largura);
	 printf("Qual o comprimento do quarto? \n");
	    scanf("%f",&comprimento);
	 printf("Quanto pagou no metro quadrado? \n");
	    scanf("%f", &valor_metro);
	 // processamento
	 total_M=largura * comprimento;
	 custo= total_M * valor_metro;
	 // saida
	 printf("O custo tota fica em torno de R$:%.2f",custo);
	 //fim
	 return 0;
 
}

