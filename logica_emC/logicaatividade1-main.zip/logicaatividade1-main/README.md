# linguagem c
atividade de logica de programacao
