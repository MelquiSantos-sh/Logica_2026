#include <stdio.h>

int main()
{                //inicio
	     // declaraçao de variaveis
	float velocidade, tamanho_do_arquivo, tempo;
	            //entradas
    printf("qual o tamanho do arquivo? \n");
      scanf("%f", &tamanho_do_arquivo);
    printf("Digite a velocidade da conexao \n");
      scanf("%f",&velocidade);
             //processamento
             
    tempo=tamanho_do_arquivo / velocidade;
      
                 //saida         
	printf("O tempo para fazer o dowload do arquivo e %.2f",tempo);
	
	return 0;
}

