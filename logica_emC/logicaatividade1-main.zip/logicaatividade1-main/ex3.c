#include <stdio.h>

	 int main()
	{
	//inicio
	//declaraçao de variaveis 
 float comissao, total_vendas;
    // entradas
  
	printf("Qual valor total das vendas?\n");
	   scanf("%f",&total_vendas);
	
	comissao= total_vendas * 0.10;
	//saida
	printf("O valor da comissão e %.2f\n",comissao);
	//fim
	return 0;
}
