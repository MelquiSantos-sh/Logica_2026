#include <stdio.h>

	int main()
{                         // inicio 
	               //declaraçao de variaveis
	
	float tanque,quilometros,media;
	 
		              //entrada
	printf("Quantos quilometros foram percorridos?\n");
	   scanf("%f",&quilometros);
	printf("Quantos litros foram gastos? \n");
	   scanf("%f",&tanque);

	    
	                 // processamento
	media= quilometros / tanque;

	                  //saida
	printf("Seu carro fez um media de %.1f por litro \n",media);
	               //fim
	 return 0;
 }
	 
