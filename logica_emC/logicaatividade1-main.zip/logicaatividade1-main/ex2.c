#include <stdio.h>

	int main ( )
{                // inicio 
	    // declaraçao de variaveis 
	float dolar, moedaB,cotacao;
	           // entrada
	printf("Digite o valor da cotaçao.");
		scanf("%f", &cotacao);
	printf ("digite o valor em dolar do item.");
		scanf("%f", &dolar);
		// processamento
	moedaB=cotacao * dolar;
	  // saida
	  printf("O valor do produto em Real e %2f",moedaB);
	  
	  //fim 	
   return 0;
   
}			
