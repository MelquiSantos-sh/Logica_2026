#include <stdio.h>

int main()
{
    int n, i;
    int x[100], y[100];
    int pescalar = 0;

    // Ler quantidade de elementos
    printf("Digite a quantidade de elementos: ");
    scanf("%d", &n);

    // Ler vetor X
    printf("\nDigite os elementos do vetor X:\n");
    for(i = 0; i < n; i++)
    {
        printf("X[%d]: ", i);
        scanf("%d", &x[i]);
    }

    // Ler vetor Y
    printf("\nDigite os elementos do vetor Y:\n");
    for(i = 0; i < n; i++)
    {
        printf("Y[%d]: ", i);
        scanf("%d", &y[i]);
    }

    // Calcular produto escalar
    for(i = 0; i < n; i++)
    {
        pescalar = pescalar + (x[i] * y[i]);
    }

    // Mostrar resultado
    printf("\nProduto escalar = %d\n", pescalar);

    return 0;
}