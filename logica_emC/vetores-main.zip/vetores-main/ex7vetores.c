#include <stdio.h>

int main()
{
    int v[20];
    int i;

    int maior, menor;
    int posMaior, posMenor;

    // Ler os valores positivos
    for(i = 0; i < 20; i++)
    {
        do
        {
            printf("Digite um numero positivo para V[%d]: ", i);
            scanf("%d", &v[i]);

            if(v[i] < 0)
            {
                printf("Numero invalido! Digite apenas positivos.\n");
            }

        } while(v[i] < 0);
    }

    // Inicializa maior e menor
    maior = v[0];
    menor = v[0];

    posMaior = 0;
    posMenor = 0;

    // Procurar maior e menor
    for(i = 1; i < 20; i++)
    {
        // Verifica maior
        if(v[i] > maior)
        {
            maior = v[i];
            posMaior = i;
        }

        // Verifica menor
        if(v[i] < menor)
        {
            menor = v[i];
            posMenor = i;
        }
    }

    // Mostrar resultados
    printf("\nMaior valor: %d\n", maior);
    printf("Posicao do maior: %d\n", posMaior);

    printf("\nMenor valor: %d\n", menor);
    printf("Posicao do menor: %d\n", posMenor);

    return 0;
}