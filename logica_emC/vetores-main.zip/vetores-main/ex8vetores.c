#include <stdio.h>

int main()
{
    int v1[10];
    int v2[10];
    int i;

    // Ler os valores do primeiro vetor
    printf("Digite 10 numeros:\n");

    for(i = 0; i < 10; i++)
    {
        printf("V1[%d]: ", i);
        scanf("%d", &v1[i]);
    }

    // Copiar em ordem inversa
    for(i = 0; i < 10; i++)
    {
        v2[i] = v1[9 - i];
    }

    // Mostrar primeiro vetor
    printf("\nPrimeiro vetor:\n");

    for(i = 0; i < 10; i++)
    {
        printf("%d ", v1[i]);
    }

    // Mostrar segundo vetor invertido
    printf("\n\nSegundo vetor invertido:\n");

    for(i = 0; i < 10; i++)
    {
        printf("%d ", v2[i]);
    }

    return 0;
}