#include <stdio.h>
int main()
{
    float vetorA[5], vetorB[5];
    int i = 0;
    for (i = 0; i < 5; i++)
    {
        printf("Digite os 5 numeros que deseja dobrar:\n");
        scanf("%f", &vetorA[i]);
        vetorB[i] = vetorA[i] * 2;
    }
    for (i = 0; i < 5; i++)
    {
        printf("O dobro de %.2f é %.2f\n", vetorA[i], vetorB[i]);
        printf("%f\n", vetorA[i]);
        vetorB[i] = vetorA[i] * 2;
    }
    for (i = 0; i < 5; i++)
    {
        printf("vetorB[%d] = %.2f\n", i, vetorB[i]);
    }
    return 0;
}
