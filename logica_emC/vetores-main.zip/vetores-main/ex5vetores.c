#include <stdio.h>

int main()
{
    int v[20];
    int i;
    int maior;
    int posicao;

    // Ler os valores
    for(i = 0; i < 20; i++)
    {
        do
        {
            printf("Digite um numero positivo para V[%d]: ", i);
            scanf("%d", &v[i]);

            if(v[i] < 0)
            {
                printf("Numero invalido! Digite apenas positivos.\n");
            }

        } while(v[i] < 0);
    }

    // Inicializa maior com o primeiro elemento
    maior = v[0];
    posicao = 0;

    // Procurar maior elemento
    for(i = 1; i < 20; i++)
    {
        if(v[i] > maior)
        {
            maior = v[i];
            posicao = i;
        }
    }

    // Mostrar resultado
    printf("\nMaior elemento: %d\n", maior);
    printf("Posicao: %d\n", posicao);

    return 0;
}