#include <stdio.h>
int main()
{
    int vetorA[10], vetorB[10];
    int i = 0;

    for (i = 0; i < 10; i++)
    {
        printf("Digite os 10 numeros que deseja dobrar:\n");
        scanf("%d", &vetorA[i]);

        if (vetorA[i] % 2 == 0)
        {
            printf("O numero %d é par\n", vetorA[i]);
            vetorB[i] = vetorA[i] * 5;
        }
        else
        {
            printf("O numero %d é ímpar\n", vetorA[i]);
            vetorB[i] = vetorA[i] + 5 ;
        }
    }
    for (i = 0; i < 10; i++)
    {
        printf("O numero %d dobrado é %d\n", vetorA[i], vetorB[i]);
    }
    return 0;

}