#include <stdio.h>

int main()
{
    float notas[20];
    float soma = 0;
    float media;
    int i;
    int acimaMedia = 0;

    // Ler as notas
    for(i = 0; i < 20; i++)
    {
        printf("Digite a nota do aluno %d: ", i + 1);
        scanf("%f", &notas[i]);

        soma = soma + notas[i];
    }

    // Calcular média
    media = soma / 20;

    // Contar alunos acima da média
    for(i = 0; i < 20; i++)
    {
        if(notas[i] > media)
        {
            acimaMedia++;
        }
    }

    // Mostrar resultados
    printf("\nMedia da turma: %.2f\n", media);
    printf("Alunos acima da media: %d\n", acimaMedia);

    return 0;
}