#include <stdio.h>

int main()
{
    int v[20];
    int i;
    int menor;
    int posicao;

    // Ler os valores positivos
    for(i = 0; i < 20; i++)
    {
        do
        {
            printf("Digite um numero positivo para V[%d]: ", i);
            scanf("%d", &v[i]);

            if(v[i] < 0)
            {
                printf("Numero invalido! Digite apenas positivos.\n");
            }

        } while(v[i] < 0);
    }

    // Inicializa o menor com o primeiro elemento
    menor = v[0];
    posicao = 0;

    // Procurar menor elemento
    for(i = 1; i < 20; i++)
    {
        if(v[i] < menor)
        {
            menor = v[i];
            posicao = i;
        }
    }

    // Mostrar resultado
    printf("\nMenor elemento: %d\n", menor);
    printf("Posicao: %d\n", posicao);

    return 0;
}